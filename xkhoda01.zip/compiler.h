#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "parse.h"
// #include "parse.c"

#include "memory.h"

#ifndef COMPILER_H
#define COMPILER_H



#endif // COMPILER_H
